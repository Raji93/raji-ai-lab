# 🔭 Raji's AI Lab

Artifacts, playbooks, and hands-on labs from AI community events, workshops, and talks I've facilitated — for Product managers, builders, and anyone curious about applied AI.

I'm Rajya Laxmi Yellajosyula (Raji), an experienced Product and Program leader who is a builder at heart. I previously spoke about my work in the AI space at conferences like Microsoft Build, Microsoft Ignite, Oracle AI World, and online technical webinars. Lately, I've also been focused on raising community awareness around AI and AI product management more broadly, speaking at MIT, AI-powered Women Conference, Product-led Summit 2026, Seattle Tech Week 2026, Seattle AI Week 2026, and a few more online forums.

This repository is a one-stop shop for the events I've conducted and supported as hands-on exercises — so if you were in the room, you can come back to it, and if you weren't, you can still get the full playbook.

## Sessions in this lab

| Event | What it covers | Folder |
|---|---|---|
| 🎤 **Seattle Tech Week 2026** — *AI Agents as Force Multipliers for Solo Product Managers* | A Scope → Build → Iterate playbook for running enterprise pilots without an engineering team | [`seattle-tech-week26-solo-pm-pilot-skills/`](./seattle-tech-week26-solo-pm-pilot-skills) |
| 🔑 **Seattle AI Week 2026** — *Keys You Shouldn't Hand Your Agent* | A playbook for staying safe with personal AI agents: what they are, who makes them, what to check before you sign up, and what never to hand over | [`seattle-ai-week26-keys-you-shouldnt-hand-your-agent/`](./seattle-ai-week26-keys-you-shouldnt-hand-your-agent) |
| 🧵 **MIT AI-Powered Women — Tinkering Lab** — *Is RAG Dead? Let's Build the Version That Isn't* | A hands-on lab building two RAG architectures live, no prior AI experience needed | [`ai-powered-women-mit/`](./ai-powered-women-mit) |

More community sessions gets added here as I run them.

## Connect

Found this from a talk or LinkedIn? I'd love to hear from you — [LinkedIn](https://www.linkedin.com/in/rajya). If something here was useful, a ⭐ on the repo helps others find it too.

## License

This project is released under CC0 1.0 (see [LICENSE](./LICENSE)). You are free to use, adapt, and share it.
